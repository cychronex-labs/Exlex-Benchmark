import json
import os
import sys

try:
    import plotly.graph_objects as go
    import plotly.io as pio
except ImportError:
    print("ERROR: Plotly is missing. Run: pip install plotly")
    sys.exit(1)

RESULTS_DIR = "results"

if not os.path.exists(RESULTS_DIR):
    print(f"ERROR: {RESULTS_DIR} not found. Run ./run_matrix.sh first.")
    sys.exit(1)

runs = sorted(
    [d for d in os.listdir(RESULTS_DIR) if os.path.isdir(os.path.join(RESULTS_DIR, d))]
)
if not runs:
    print("ERROR: No benchmark data found.")
    sys.exit(1)

latest_run = runs[-1]
backup_dir = os.path.join(RESULTS_DIR, latest_run, "raw_criterion_backup")

print(f"=> Analyzing Data from Run: {latest_run}")

db = {}

# 1. Parse Criterion Speed Data
for root, dirs, files in os.walk(backup_dir):
    if "estimates.json" in files:
        with open(os.path.join(root, "estimates.json")) as f:
            data = json.load(f)
            point_est = data["mean"]["point_estimate"]

        rel_path = os.path.relpath(root, backup_dir)
        parts = rel_path.split(os.sep)

        # Ensure we are only reading the "new" results
        if not parts or parts[-1] != "new":
            continue

        id_parts = parts[:-1]
        if not id_parts:
            continue

        group = id_parts[0]
        full_name = "_".join(id_parts).lower()

        if "serde" in full_name:
            parser = "Serde JSON"
        elif "exlex" in full_name or "vml" in full_name:
            parser = "Exlex (DOD)"
        elif "toml_edit" in full_name or "tomledit" in full_name:
            parser = "TOML Edit"
        elif "toml" in full_name:
            parser = "TOML"
        elif "ini" in full_name:
            parser = "INI"
        elif "sonic" in full_name:
            parser = "Sonic-RS (SIMD)"
        elif "simd" in full_name:
            parser = "SIMD-JSON"
        elif "quick" in full_name:
            parser = "Quick-XML"
        elif "figment" in full_name:
            parser = "Figment (Layer)"
        else:
            parser = id_parts[1].capitalize() if len(id_parts) > 1 else "Unknown"

        if len(id_parts) == 2:
            scenario = id_parts[1]
        elif len(id_parts) >= 3:
            scenario = "_".join(id_parts[2:])
        else:
            scenario = "Default"

        if group not in db:
            db[group] = {}
        if scenario not in db[group]:
            db[group][scenario] = {}
        db[group][scenario][parser] = point_est

# 2. Okabe-Ito Colorblind Safe Palette
COLOR_MAP = {
    "Exlex (DOD)": "#00e5ff",
    "Serde JSON": "#E69F00",
    "Sonic-RS (SIMD)": "#009E73",
    "SIMD-JSON": "#56B4E9",
    "TOML": "#999999",
    "TOML Edit": "#F0E442",
    "INI": "#D55E00",
    "Quick-XML": "#CC79A7",
    "Figment (Layer)": "#0072B2",
}

html_graphs = []

# 3. Generate Criterion Speed Graphs
for group in sorted(db.keys()):
    scenarios = db[group]
    parsers_in_group = set()
    for s in scenarios.values():
        parsers_in_group.update(s.keys())

    fig = go.Figure()
    sorted_parsers = sorted(list(parsers_in_group))
    if "Exlex (DOD)" in sorted_parsers:
        sorted_parsers.remove("Exlex (DOD)")
        sorted_parsers.insert(0, "Exlex (DOD)")

    for p in sorted_parsers:
        x_vals = sorted(list(scenarios.keys()))
        y_vals = [scenarios[s].get(p, 0) for s in x_vals]
        fig.add_trace(
            go.Bar(name=p, x=x_vals, y=y_vals, marker_color=COLOR_MAP.get(p, "#ffffff"))
        )

    fig.update_layout(
        title=f"Benchmark Group: {group.replace('_', ' ').capitalize()}",
        barmode="group",
        template="plotly_dark",
        yaxis_title="Time (Nanoseconds) ↓ Lower is Better",
        xaxis_title="Topology / Scenario",
        font=dict(family="system-ui", size=14),
        margin=dict(t=60, b=40, l=40, r=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    html_graphs.append(fig.to_html(full_html=False, include_plotlyjs=False))

# 4. Generate Allocation Audit Graphs (Memory)
mem_file = os.path.join(RESULTS_DIR, latest_run, "memory_results.json")
if os.path.exists(mem_file):
    with open(mem_file) as f:
        mem_data = json.load(f)

    # Insert a visual break in the HTML
    html_graphs.append(
        "<h2 style='color:#00e5ff; border-bottom: 1px solid #333; padding-bottom: 10px; margin-top: 50px;'>The Allocation Audit (Memory Overhead)</h2>"
    )

    metrics = [
        ("blocks", "Heap Allocations (Count)"),
        ("bytes", "Heap Footprint (Bytes)"),
    ]

    for metric_key, metric_title in metrics:
        fig = go.Figure()

        parsers = sorted(
            list(set([d["parser"] for d in mem_data if d["parser"] != "Unknown"]))
        )
        if "Exlex (DOD)" in parsers:
            parsers.remove("Exlex (DOD)")
            parsers.insert(0, "Exlex (DOD)")

        for p in parsers:
            x_vals = ["Parse Init", "Mutation Overhead"]
            y_vals = [
                next(
                    (
                        d[metric_key]
                        for d in mem_data
                        if d["parser"] == p and d["op"] == "parse"
                    ),
                    0,
                ),
                next(
                    (
                        d[metric_key]
                        for d in mem_data
                        if d["parser"] == p and d["op"] == "mutate"
                    ),
                    0,
                ),
            ]
            fig.add_trace(
                go.Bar(
                    name=p, x=x_vals, y=y_vals, marker_color=COLOR_MAP.get(p, "#ffffff")
                )
            )

        fig.update_layout(
            title=metric_title,
            barmode="group",
            template="plotly_dark",
            yaxis_title=metric_title + " ↓ Lower is Better",
            font=dict(family="system-ui", size=14),
            margin=dict(t=60, b=40, l=40, r=40),
            legend=dict(
                orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1
            ),
        )
        html_graphs.append(fig.to_html(full_html=False, include_plotlyjs=False))

# 5. Compile the HTML
FINAL_HTML = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exlex Telemetry | {latest_run}</title>
    <script src="https://cdn.plot.ly/plotly-2.32.0.min.js"></script>
    <style>
        body {{ background-color: #111111; color: #ffffff; font-family: system-ui, sans-serif; margin: 0; padding: 20px; }}
        h1 {{ text-align: center; margin-bottom: 5px; color: #00e5ff; }}
        h3 {{ text-align: center; margin-top: 0; margin-bottom: 40px; color: #888; font-weight: 400; }}
        .graph-container {{ max-width: 1400px; margin: 0 auto 50px auto; background: #1e1e1e; border-radius: 8px; padding: 15px; box-shadow: 0 10px 20px rgba(0,0,0,0.5); }}
    </style>
</head>
<body>
    <h1>Exlex Performance Matrix</h1>
    <h3>Timestamp: {latest_run}</h3>
    {"".join([f'<div class="graph-container">{g}</div>' for g in html_graphs])}
</body>
</html>
"""

output_file = f"dashboard_{latest_run}.html"
with open(output_file, "w") as f:
    f.write(FINAL_HTML)

print(f"=> Telemetry Complete! Open {output_file} in your browser.")
